#pragma once

#include "Button.h"

class Switch : public Button
{
public:
	Switch();
	virtual ~Switch();

	//void setButtonSpecs(int, int, int, int);
	void setCharacter(char);
	char getCharacter(void);

	bool getClickedState(void);
	void setClickedState(bool);
	bool getIsActiveState(void);
	void setIsActiveState(bool);

	bool isSwitchOn(SDL_Event*);

private:
	bool bIsClicked = false;
	bool bIsActive = true;
	char character;
};

