#pragma once

#include <time.h>
#include <iostream>
using namespace std;

class Timer
{
public:
	Timer();
	virtual ~Timer();

	void start(unsigned int&);
	void stop(void);

private:
	bool bRunning = true;
	bool bInit = false;
	unsigned int startTime;
	unsigned int pastTime;
	unsigned int plTime;
};

