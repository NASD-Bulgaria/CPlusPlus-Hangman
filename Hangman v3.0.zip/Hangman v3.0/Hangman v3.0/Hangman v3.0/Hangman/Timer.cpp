#include "stdafx.h"
#include "Timer.h"


Timer::Timer()
{
}


Timer::~Timer()
{
}

void Timer::start(unsigned int& time)
{ 
	if (bRunning)
	{
		if (!bInit)
		{
			time -= 1;
			plTime = time;
			this->bInit = true;
			this->startTime = (unsigned int)clock();
		}
		else
		{
			this->pastTime = ((unsigned int)clock() - this->startTime) / CLOCKS_PER_SEC;
			time = plTime - pastTime;
		}
		if (time == 0)
		{
			stop();
		}
	}
}

void Timer::stop(void)
{
	bRunning = false;
	bInit = false;
}