#include "stdafx.h"
#include "SecondScreen.h"


SecondScreen::SecondScreen()
{
}


SecondScreen::~SecondScreen()
{
}

//void SecondScreen::init(Round& round)
//{
//	//this->credit = round.getCredit();
//}

void SecondScreen::setCatButtonsState(bool f, bool s, bool t)
{
	this->fClicked = f;
	this->sClicked = s;
	this->tClicked = t;
}

Button SecondScreen::getStartButton(void)
{
	return this->startButton;
}

Button SecondScreen::getIncreaseBet(void)
{
	return this->increaseBidButton;
}

Button SecondScreen::getDecreaseBet(void)
{
	return this->decreaseBidButton;
}

Button SecondScreen::getFirstCatButton(void)
{
	return this->firstCatButton;
}

Button SecondScreen::getSecondCatButton(void)
{
	return this->secondCatButton;
}

Button SecondScreen::getThirdCatButton(void)
{
	return this->thirdCatButton;
}

string SecondScreen::getStringToPrecDouble(double d)
{
	stringstream str;
	str << fixed << setprecision(1) << d;
	string cr = str.str();
	return cr;
}

void SecondScreen::setLocalVars(Round& round)
{
	this->credit = round.getCredit();
	this->bid = round.getBid();
}

void SecondScreen::increaseBid(Round& round)
{
	this->bid = round.getBid();
	this->credit = round.getCredit();

	if (this->credit >= 10.0)
	{
		if (this->bid == 0.0)
		{
			this->bid = 10.0;
		}
		else if (this->bid <= this->credit - 1.0)
		{
			this->bid += 1.0;
		}
		else if (this->bid > this->credit - 1.0)
		{
			this->bid = this->credit;
		}
	}
	if (this->credit < 10.0)
	{
		this->bid = this->credit;
	}
	if (this->bid > 100.0)
	{
		this->bid = 100.0;
	}
	if (this->bid < 0.0)
	{
		this->bid = 0.0;
	}

	round.setBid(this->bid);
	round.setCredit(this->credit);
}

void SecondScreen::decreaseBid(Round& round)
{
	this->bid = round.getBid();
	this->credit = round.getCredit();

	cout << "decrease" << endl;
	if (this->bid < 11.0)
	{
		this->bid = 0.0;
	}
	if (this->bid >= 11.0)
	{
		this->bid--;
	}

	round.setBid(this->bid);
	round.setCredit(this->credit);
}

bool SecondScreen::isStartButtonActive(void)
{
	return ((this->bid > 0) && (this->fClicked || this->sClicked || this->tClicked));
}

void SecondScreen::DrawScreen(SDL_Surface* &m_Surface)
{
	//credit sign
	SDL_Color fontColor = { 0, 0, 0 };
	drawer.SetFont(60, fontColor);
	drawer.drawText(450, 60, "Credit", m_Surface);

	//credit value display
	int dummyCredit = 100;
	drawer.SetFont(60, fontColor);
	drawer.drawText(450, 120, getStringToPrecDouble(this->credit), m_Surface);

	//
	//bet sign
	drawer.SetFont(60, fontColor);
	drawer.drawText(450, 490, "Bet", m_Surface);

	//bet value display
	//dummyCredit = 10;
	fontColor = { 255, 0, 0 };
	drawer.SetFont(60, fontColor);
	drawer.drawText(480, 550, getStringToPrecDouble(this->bid), m_Surface);

	//+
	//SDL_Color statRectColor = { 0, 255, 0 };
	//SDL_Rect statRectSize = { 545, 530, 28, 55 };
	//drawer.drawRect(statRectSize, statRectColor, m_Surface);
	increaseBidButton.setButtonSpecs(595, 550, 28, 55);
	drawer.SetFont(60, fontColor);
	drawer.drawText(595, 550, "+", m_Surface);
	//-
	//statRectSize = { 450, 530, 28, 55 };
	//drawer.drawRect(statRectSize, statRectColor, m_Surface);
	decreaseBidButton.setButtonSpecs(450, 550, 28, 55);
	drawer.SetFont(60, fontColor);
	drawer.drawText(450, 550, "-", m_Surface);

	//Animals
	//SDL_Color firstCategoryColor = { 0, 255, 0 };
	//SDL_Rect firstCategoryRect = { 65, 150, 320, 65 };
	//drawer.drawRect(firstCategoryRect, firstCategoryColor, m_Surface);
	firstCatButton.setButtonSpecs(65, 150, 320, 65);
	drawer.SetFont(70, fontColor);
	drawer.drawText(65, 150, "Animals", m_Surface);

	//States
	//SDL_Color secondCategoryColor = { 0, 255, 0 };
	//SDL_Rect secondCategoryRect = { 65, 300, 225, 65 };
	//drawer.drawRect(secondCategoryRect, secondCategoryColor, m_Surface);
	secondCatButton.setButtonSpecs(65, 300, 270, 65);
	drawer.SetFont(70, fontColor);
	drawer.drawText(65, 300, "States", m_Surface);

	//Common
	//SDL_Color thirdCategoryColor = { 0, 255, 0 };
	//SDL_Rect thirdCategoryRect = { 65, 450, 335, 65 };
	//drawer.drawRect(thirdCategoryRect, thirdCategoryColor, m_Surface);
	thirdCatButton.setButtonSpecs(65, 450, 335, 65);
	drawer.SetFont(70, fontColor);
	drawer.drawText(65, 450, "Common", m_Surface);

	//debug
	if (fClicked) drawer.drawText(15, 150, "$", m_Surface);
	if (sClicked) drawer.drawText(15, 300, "$", m_Surface);
	if (tClicked) drawer.drawText(15, 450, "$", m_Surface);

	//Start Button
	//SDL_Color startButtonColor = { 0, 255, 0 };
	//SDL_Rect startButtonRect = { 450, 300, 300, 85 };
	//drawer.drawRect(startButtonRect, startButtonColor, m_Surface);
	startButton.setButtonSpecs(450, 300, 300, 85);
	drawer.SetFont(90, fontColor);
	drawer.drawText(450, 300, "Start", m_Surface);
}