#pragma once

#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <iostream>
#include <map>
using std::string;
using std::map;

class Draw
{
private:
	TTF_Font* font;
	map<int, TTF_Font*> FontSizes;
	SDL_Color color;

public:
	Draw();
	~Draw();

	void drawRect(SDL_Rect rect, SDL_Color color, SDL_Surface* &m_Surface);
	void drawPicture(int xPos, int yPos, SDL_Surface* &Picture,SDL_Surface* &m_Surface);

	void SetFont(int fontSize, SDL_Color color);
	void SetFontSecond(int fontSize, SDL_Color color);
	void drawText(int xPos, int yPos, const string& text,SDL_Surface* &m_Surface);
	TTF_Font* GetFont(int FontSize);
	//TTF_Font* GetFontSecond(int FontSize);
};
