#pragma once
#include "Round.h"
#include "Draw.h"
#include "Button.h"

class SecondScreen
{
public:
	SecondScreen();
	virtual ~SecondScreen();

	void setCatButtonsState(bool, bool, bool);

	//void init(Round&);
	Button getStartButton(void);
	Button getIncreaseBet(void);
	Button getDecreaseBet(void);
	Button getFirstCatButton(void);
	Button getSecondCatButton(void);
	Button getThirdCatButton(void);

	string getStringToPrecDouble(double);
	void setLocalVars(Round&);

	void increaseBid(Round&);
	void decreaseBid(Round&);

	bool isStartButtonActive(void);

	void DrawScreen(SDL_Surface* &m_Surface);

	
private:
	Draw drawer;
	Button startButton;
	Button increaseBidButton;
	Button decreaseBidButton;
	Button firstCatButton;
	Button secondCatButton;
	Button thirdCatButton;
	double credit;
	double bid;

	bool fClicked = false;
	bool sClicked = false;
	bool tClicked = false;
};

