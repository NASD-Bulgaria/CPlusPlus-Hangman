#pragma once

#include <ctime>
#include <string>
using namespace std;

class Round
{
public:
	Round();
	virtual ~Round();

	void init(void);
	void saveCredit(void);
	void loadCredit(void);

///TODO ���� ������� �� �� ���� �� Round � �� �� ���������� �� ����
	//void increseCredit(void);
	//void decreseCredit(void);

	//void saveLastTenRounds(void);

	void saveRoundDataToXML(void);

	double getCredit(void);
	void setCredit(double);
	double getBid(void);
	void setBid(double);
	double getEarning(void);
	void setEarning(double);
	double getTimeFactor(void);
	void setTimeFactor(double);

	string getPlayingTime(void);
	void setPlayingTime(void);
	string getStartTime(void);
	void setStartTime(void);
	string getStopTime(void);
	void setStopTime(void);

	string getCurentTime(void);

private:
	string startTime;
	string stopTime;
	string playingTime;
	double credit;
	double bid;
	double earning;
	double timeFactor;
	unsigned int timeWindow;
};

