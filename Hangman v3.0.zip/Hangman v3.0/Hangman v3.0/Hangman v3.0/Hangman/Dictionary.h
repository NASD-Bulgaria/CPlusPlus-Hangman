#pragma once
#include <iostream>
#include "stdafx.h"
#include <string>
using namespace std;

class Dictionary
{
public:
	Dictionary();
	~Dictionary();

	enum eCategory{ FIRST_CAT = 1, SECOND_CAT, THIRD_CAT };

	string getCurrentWord(void);

	void init(void);

	void readCategoryFile(string, vector<string>&);

	void genRandWord(vector<string>&);
	void chooseCategory(eCategory);
	
private:
	vector<string> firstCategory;
	vector<string> secondCategory;
	vector<string> thirdCategory;
	string currentWord;
};

