#pragma once
#include <SDL.h>
#include "FirstScreen.h"
#include "SecondScreen.h"
#include "ThirdScreen.h"
#include "Round.h"
#include "Dictionary.h"
#include "WriteXml.h"
#include <iostream>
using namespace std;


class GameHandler
{
public:
	GameHandler();
	~GameHandler();

	const int getWindowWidth(void);
	const int getWindowHeight(void);

	void init(void);
	void run(void);

private:
	enum eGameState{FIRST_SCREEN, SECOND_SCREEN, THIRD_SCREEN};
	eGameState currentScreen;

	Round round;
	//RoundHandler hangman;
	Dictionary* dictionary = new Dictionary();
	FirstScreen firstScreen;
	SecondScreen secondScreen;
	ThirdScreen thirdScreen;
	
	//FirstScreen firstScreenInit;
	//SecondScreen secondScreenInit;

	bool quit = false;
	static const int windowWidth = 1200;
	static const int windowHeight = 675;

	SDL_Window*  m_Window;
	SDL_Surface* m_Surface;
	SDL_Renderer* m_Renderer;
	SDL_Surface* m_BackGround;
	SDL_Event event;

	void gameExec(void);
	void draw();
	void close(void);
};

