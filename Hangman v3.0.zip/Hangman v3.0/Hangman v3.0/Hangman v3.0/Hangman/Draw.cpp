#include "stdafx.h"
#include "Draw.h"


Draw::Draw(void)
{
	if(TTF_Init() < 0) 
	{
		std::cout << "TTF ERROR\n";
	}
}
Draw::~Draw(void)
{}


void Draw::drawRect(SDL_Rect rect, SDL_Color color, SDL_Surface* &m_Surface)
{
	SDL_FillRect(m_Surface, &rect,  SDL_MapRGB(m_Surface->format,color.r, color.g, color.b));
}

void Draw::drawPicture(int xPos, int yPos, SDL_Surface* &Picture,SDL_Surface* &m_Surface)
{
	SDL_Rect rect;
	rect.x = xPos;
	rect.y = yPos;
	rect.w = Picture->w;
	rect.h = Picture->h;

	SDL_BlitSurface(Picture,NULL,m_Surface,&rect);
}

void Draw::SetFont(int fontSize, SDL_Color color)
{
	font = GetFont(fontSize);
	this->color = color;
}

void Draw::drawText(int xPos, int yPos, const string& text, SDL_Surface* &m_Surface)
{
	SDL_Surface *textSurface = TTF_RenderText_Solid(font, text.c_str(), color);
	SDL_Rect posToDraw = {xPos,yPos,NULL,NULL};
	SDL_BlitSurface(textSurface,NULL,m_Surface,&posToDraw);
	SDL_FreeSurface(textSurface);
}

TTF_Font* Draw::GetFont(int FontSize)
{
	std::map<int, TTF_Font*>::iterator it;
	it = FontSizes.find(FontSize);

	if (it != FontSizes.end())
		return it->second;
	else
	{
		TTF_Font* mFont = TTF_OpenFont("resources/fonts/Capture_it_2.ttf", FontSize);
		FontSizes.insert(std::pair<int, TTF_Font*>(FontSize, mFont));
		return mFont;
	}		
}