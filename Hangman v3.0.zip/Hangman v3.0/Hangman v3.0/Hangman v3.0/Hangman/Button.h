#pragma once
#include <SDL.h>
#include <iostream>
using namespace std;

class Button : public SDL_Rect
{
public:
	Button() : SDL_Rect()
	{}

	~Button()
	{}

	void setButtonSpecs(int x, int y, int w, int h)
	{
		this->x = x;
		this->y = y;
		this->w = w;
		this->h = h;
	}

	int getButtonX(void)
	{
		return this->x;
	}
	int getButtonY(void)
	{
		return this->y;
	}
	int getButtonW(void)
	{
		return this->w;
	}
	int getButtonH(void)
	{
		return this->h;
	}

	bool Button::isClicked(SDL_Event* e)
	{
		if (e->type == SDL_MOUSEMOTION || e->type == SDL_MOUSEBUTTONDOWN || e->type == SDL_MOUSEBUTTONUP)
		{
			int xb = e->button.x;
			int yb = e->button.y;

			//debug
			//std::cout << xb << " mouse position " << yb << std::endl;
			//if (xb > this->x) cout << "1" << endl;
			//if (xb < (this->x + this->w)) cout << "2" << endl;
			//if (yb > this->y) cout << "3" << endl;
			//if (yb < (this->y + this->h)) cout << "4" << endl;
			//if (e->type == SDL_MOUSEBUTTONDOWN) cout << "5" << endl;
			//std::cout << xb << " mouse position " << yb << std::endl;

			return ((xb > this->x) && (xb < (this->x + this->w)) && (yb > this->y) && (yb < (this->y + this->h)) && (e->type == SDL_MOUSEBUTTONDOWN));
		}
	}

};
