#include "stdafx.h"
#include "ClickButton.h"


ClickButton::ClickButton() : Button()
{
}


ClickButton::~ClickButton()
{
}
