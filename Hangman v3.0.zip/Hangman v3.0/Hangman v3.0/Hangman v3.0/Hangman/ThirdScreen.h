#pragma once
#include "Round.h"
#include "Draw.h"
#include "Button.h"
#include "Timer.h"
#include "Keyboard.h"

#include <list>
#include <vector>
using namespace std;

class ThirdScreen
{
public:
	ThirdScreen();
	virtual ~ThirdScreen();

	//enum eGameResult{ GAME_OVER, WIN };

	unsigned int getTimer(void);

	void init(void);
	string getStringToPrecDouble(double);
	void onEnter(Round&, string);
	void onExit(Round&);
	void genRandTimeWindow(void);
	bool getWinning(void);
	bool getLoosing(void);
	bool getRoundRunning(void);
	double getCredit(void);
	double getBid(void);
	double getEarning(void);
	
	void saveRoundInfo(Round&);
	void writeRoundInfoToFile(void);

	void runRound(char);

	void DrawScreen(SDL_Surface* m_Surface);
	
	Keyboard keyboard;
	//gTexture* gTexture;
	
private:
	Draw drawer;
	Button playButton;
	Timer stopwatch;

	string startTime;
	string stopTime;
	string playingTime;
	double earning;
	double timeFactor;
	double credit;
	double bid;
	unsigned int timeWindow;

	unsigned int timer;
	int playerLives;
	string currentWord;
	string guessWord;
	int unknownChars;
	bool roundRunning = false;
	bool winning = false;
	bool loosing = false;
	//eGameResult gResult;
	//char userGuess;
	//vector<int> visibleChars;
	//vector<char> data;

	list<Round> roundsList;
	
	Keyboard keyboardInit;
	Timer stopwatchInit;
	
};

