#include "stdafx.h"
#include "Switch.h"


Switch::Switch() : Button()
{
}

Switch::~Switch()
{
}

//void Switch::setButtonSpecs(int x, int y, int w, int h)
//{
//	this->x = x;
//	this->y = y;
//	this->w = w;
//	this->h = h;
//}

void Switch::setCharacter(char ch)
{
	this->character = ch;
}
char Switch::getCharacter(void)
{
	return this->character;
}
bool Switch::getClickedState(void)
{
	return this->bIsClicked;
}
void Switch::setClickedState(bool state)
{
	this->bIsClicked = state;
}
bool Switch::getIsActiveState(void)
{
	return this->bIsActive;
}
void Switch::setIsActiveState(bool state)
{
	this->bIsActive = state;
}
bool Switch::isSwitchOn(SDL_Event* e)
{
	if (isClicked(e) && (this->bIsClicked == false))
	{
		this->bIsClicked = true;
	}
	else
	{
		//do nothing
	}
	return this->bIsClicked;
}
