#pragma once

#include "Round.h"
#include "Draw.h"
#include "Switch.h"

#include <vector>

class Keyboard
{
public:
	Keyboard();
	virtual ~Keyboard();

	void init(void);

	void draw(SDL_Surface*);
	char handleEvents(SDL_Event*);

private:
	SDL_Surface* s_Keyboard;
	SDL_Surface* s_KeyboardDarkened;
	vector<Switch> keySet;
	SDL_Rect keyboardPosition;

	//debug
	Draw drawer;
};

