#pragma once

#include "Button.h"

class ClickButton : public Button
{
public:
	ClickButton();
	virtual ~ClickButton();
};

