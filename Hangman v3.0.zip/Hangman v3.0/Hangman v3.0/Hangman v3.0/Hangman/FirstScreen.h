#pragma once
#include "Round.h"
#include "Draw.h"
#include "Button.h"
#include <vector>

class FirstScreen
{
public:
	FirstScreen();
	~FirstScreen();
	void init(Round&);

	void onEnter(Round& round);
	void readRoundInfoFromFile(void);
	Button getPlayButton(void);
	Button getIncreaseCreditButton(void);
	Button getDecreseCreditButton(void);

	//string getStringCredit(void);
	string getStringToPrecDouble(double);

	void increseCredit(Round&);
	void decreaseCredit(Round&);

	void DrawScreen(SDL_Surface* &m_Surface);
	
	bool isPlayButtonActive(void);
private:
	Draw drawer;
	
	Button playButton;
	Button increaseCredit;
	Button decreseCredit;
	double credit;

	vector<string> roundsList;
};

