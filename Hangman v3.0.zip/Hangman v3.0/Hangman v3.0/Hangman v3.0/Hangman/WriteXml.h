#include "Round.h"
class WriteXml
{
public:
	WriteXml();
	~WriteXml();

	static void newXml(Round&);

};
