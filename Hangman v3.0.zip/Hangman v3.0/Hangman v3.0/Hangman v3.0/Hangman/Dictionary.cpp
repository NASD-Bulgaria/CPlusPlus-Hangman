#include "stdafx.h"
#include <fstream>
#include <string>
#include <cstring>
#include <ctime>
#include <cstdlib>
#include <vector>
#include <ctime>
#include <time.h>
#include <math.h>
#include "Dictionary.h"

#include <assert.h>

using namespace std;


Dictionary::Dictionary()
{
}
Dictionary::~Dictionary()
{
}

string Dictionary::getCurrentWord()
{
	return this->currentWord;
}

void Dictionary::init(void)
{
	readCategoryFile("resources/categories/animals.txt", this->firstCategory);
	readCategoryFile("resources/categories/countries.txt", this->secondCategory);
	readCategoryFile("resources/categories/others.txt", this->thirdCategory);
}

void Dictionary::readCategoryFile(string fileName, vector<string>& categoryList)
{
	ifstream ifs(fileName);
	string temp;
	while (ifs >> temp)
	{
		categoryList.push_back(temp);
	}
}

void Dictionary::genRandWord(vector<string>& vec)
{
	string word;
	for (size_t i = 0; i < vec.size(); i++)
	{
		srand(time(0));
		int randomIndex = rand() % vec.size() + 1;
			
		word = vec[randomIndex - 1];
	}
	this->currentWord = word;
}

void Dictionary::chooseCategory(eCategory choice)
{
	switch (choice)
	{
	case FIRST_CAT: genRandWord(this->firstCategory); break;
	case SECOND_CAT: genRandWord(this->secondCategory); break;
	case THIRD_CAT: genRandWord(this->thirdCategory); break;
	}
}