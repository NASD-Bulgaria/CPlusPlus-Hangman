#include "stdafx.h"
#include "GameHandler.h"

GameHandler::GameHandler()
{}

GameHandler::~GameHandler()
{}

void GameHandler::init()
{
	currentScreen = FIRST_SCREEN;
	bool success = true;

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("SDL could not initialize! SDL Error: %s\n", SDL_GetError());
		success = false;
	}

    m_Window = SDL_CreateWindow( "Hangman", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, windowWidth, windowHeight, SDL_WINDOW_SHOWN );
	if (m_Window == NULL)
	{
		printf("Window could not be created! SDL Error: %s\n", SDL_GetError());
		success = false;
	}

	m_Renderer = SDL_CreateRenderer(m_Window, -1, SDL_RENDERER_ACCELERATED);
	if (m_Renderer == NULL)
	{
		printf("Renderer could not be created! SDL Error: %s\n", SDL_GetError());
		success = false;
	}

	m_Surface = SDL_GetWindowSurface(m_Window);
	m_BackGround = SDL_LoadBMP("resources/background/game_background.bmp");
	
	round.init();
	dictionary->init();
	firstScreen.init(round);
	//secondScreen.Init(round);
	//thirdScreen.init();
}
void GameHandler::run()
{
	while (!quit)
	{
		while (SDL_PollEvent(&event))
		{
			if (event.type == SDL_QUIT)
			{
				quit = true;
			}

			if (event.type == SDL_MOUSEBUTTONDOWN)
			{
				//debug
				cout << event.button.x << "  " << event.button.y << endl;

				switch (currentScreen)
				{
				case FIRST_SCREEN:
				{
									 if (firstScreen.getPlayButton().isClicked(&event) && firstScreen.isPlayButtonActive())
									 {
										 currentScreen = SECOND_SCREEN;
										 secondScreen.setLocalVars(round);
									 }
									 else if (firstScreen.getIncreaseCreditButton().isClicked(&event))
									 {
										 firstScreen.increseCredit(round);
									 }
									 else if (firstScreen.getDecreseCreditButton().isClicked(&event))
									 {
										 firstScreen.decreaseCredit(round);
									 }
				}
				case SECOND_SCREEN:
				{
									  if (secondScreen.getStartButton().isClicked(&event) && secondScreen.isStartButtonActive())
									  {
										  currentScreen = THIRD_SCREEN;
										  thirdScreen.onEnter(round, dictionary->getCurrentWord());
										  //hangman.init(dictionary->getCurrentWord());
									  }
									  else if (secondScreen.getIncreaseBet().isClicked(&event))
									  {
										  secondScreen.increaseBid(this->round);
									  }
									  else if (secondScreen.getDecreaseBet().isClicked(&event))
									  {
										  secondScreen.decreaseBid(this->round);
									  }
									  else if (secondScreen.getFirstCatButton().isClicked(&event))
									  {
										  secondScreen.setCatButtonsState(true, false, false);
										  //generate random word
										  dictionary->chooseCategory(dictionary->FIRST_CAT);
										  cout << dictionary->getCurrentWord() << endl;//debug
									  }
									  else if (secondScreen.getSecondCatButton().isClicked(&event))
									  {
										  secondScreen.setCatButtonsState(false, true, false);
										  //generate random word
										  dictionary->chooseCategory(dictionary->SECOND_CAT);
										  cout << dictionary->getCurrentWord() << endl;//debug
									  }
									  else if (secondScreen.getThirdCatButton().isClicked(&event))
									  {
										  secondScreen.setCatButtonsState(false, false, true);
										  //generate random word
										  dictionary->chooseCategory(dictionary->THIRD_CAT);
										  cout << dictionary->getCurrentWord() << endl;//debug
									  }
				}
				case THIRD_SCREEN:
				{
									 //hangman.runRound(round);
									 //thirdScreen.getTimer();
									 //cout << thirdScreen.getTimer() << endl;
									 char userGuess = thirdScreen.keyboard.handleEvents(&event);
									 //cout << userGuess << endl;
									 thirdScreen.runRound(userGuess);
									 
				}

				}
			}
		}
		draw();
	}
	close();
}

void GameHandler::gameExec(void)
{
	if (!thirdScreen.getRoundRunning() && thirdScreen.getLoosing())
	{ 
		thirdScreen.onExit(round);
		round.setEarning(0.0);
		
		
		cout << "th bid: " << thirdScreen.getBid() << endl;
		cout << "th credit: " << thirdScreen.getCredit() << endl;

		WriteXml::newXml(round);
		round.setCredit(thirdScreen.getCredit() - thirdScreen.getBid());
		round.saveCredit();

		if (round.getCredit() > 0.0)
		{
			currentScreen = SECOND_SCREEN;
			//secondScreen = secondScreenInit;
			round.setBid(0.0);
			secondScreen.setLocalVars(round);
			secondScreen.setCatButtonsState(false, false, false);

			cout << "time factor: " << round.getTimeFactor() << endl;
			cout << "earning: " << round.getEarning() << endl;
			cout << "credit: " << round.getCredit() << endl;
		}
		else if (round.getCredit() <= 0.0)
		{
			currentScreen = FIRST_SCREEN;
			//firstScreen = firstScreenInit;
			round.setBid(0.0);
			firstScreen.onEnter(round);

			cout << "time factor: " << round.getTimeFactor() << endl;
			cout << "earning: " << round.getEarning() << endl;
			cout << "credit: " << round.getCredit() << endl;
		}
	}
	if (!thirdScreen.getRoundRunning() && thirdScreen.getWinning())
	{
		//cout << "I'm winnin" << endl;
		thirdScreen.onExit(round);
		

		cout << "time factor: " << round.getTimeFactor() << endl;
		cout << "earning: " << round.getEarning() << endl;
		cout << "credit: " << round.getCredit() << endl;

		WriteXml::newXml(round);
		round.setCredit(thirdScreen.getCredit() + round.getEarning());
		round.saveCredit();
		currentScreen = SECOND_SCREEN;
		//secondScreen = secondScreenInit;
		secondScreen.setLocalVars(round);
		secondScreen.setCatButtonsState(false, false, false);
	}
}

void GameHandler::draw()
{
	SDL_BlitSurface(m_BackGround, NULL, m_Surface, NULL);

	switch(currentScreen)
	{
	case FIRST_SCREEN: firstScreen.DrawScreen(m_Surface); break;
	case SECOND_SCREEN: secondScreen.DrawScreen(m_Surface); break;
	case THIRD_SCREEN: thirdScreen.DrawScreen(m_Surface); gameExec(); break;
	default: break;
	}

	SDL_UpdateWindowSurface(m_Window);
}

void GameHandler::close(void)
{
	round.saveCredit();
	//Destroy obj
	delete dictionary;
	//Destroy window
	SDL_DestroyRenderer(m_Renderer);
	SDL_DestroyWindow(m_Window);
	m_Window = NULL;
	m_Renderer = NULL;

	//Quit SDL subsystems
	IMG_Quit();
	SDL_Quit();
}