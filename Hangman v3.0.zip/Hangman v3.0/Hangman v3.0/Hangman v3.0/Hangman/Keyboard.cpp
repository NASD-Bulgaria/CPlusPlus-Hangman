#include "stdafx.h"
#include "Keyboard.h"


Keyboard::Keyboard()
{
}


Keyboard::~Keyboard()
{
}

void Keyboard::init(void)
{
	keyboardPosition.x = 90;
	keyboardPosition.y = 400;
	s_Keyboard = IMG_Load("resources/keyboard.png");
	//s_KeyboardDarkened = IMG_Load("resources/keyboardDarkened.png");

	Switch switchButton;
	//row 1
	int xPos = keyboardPosition.x;
	int yPos = keyboardPosition.y + 2;
	for (size_t i = 1; i <= 10; ++i)
	{
		switchButton.setButtonSpecs(xPos, yPos, 90, 55);
		xPos += 99;
		this->keySet.push_back(switchButton);
	}
	//row 2
	xPos = keyboardPosition.x;
	yPos = keyboardPosition.y + 75;
	for (size_t i = 1; i <= 9; ++i)
	{
		switchButton.setButtonSpecs(xPos, yPos, 90, 55);
		xPos += 99;
		this->keySet.push_back(switchButton);
	}
	//row 3
	xPos = keyboardPosition.x + 100;
	yPos = keyboardPosition.y + 147;
	for (size_t i = 1; i <= 7; ++i)
	{
		switchButton.setButtonSpecs(xPos, yPos, 90, 55);
		xPos += 99;
		this->keySet.push_back(switchButton);
	}
	//qwerty
	char qwerty[26] = {'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'z', 'x', 'c', 'v', 'b', 'n', 'm'};
	for (int i = 0; i < keySet.size(); ++i)
	{
		this->keySet[i].setCharacter(qwerty[i]);
	}
}

void Keyboard::draw(SDL_Surface* m_Surface)
{
	//SDL_Rect DestR;
	//SDL_BlitSurface(s_KeyboardDarkened, NULL, m_Surface, &keyboardPosition);
	SDL_BlitSurface(s_Keyboard, NULL, m_Surface, &keyboardPosition);
	
	for (int i = 0; i < keySet.size(); ++i)
	{
		//SDL_BlitSurface(s_Keyboard, &DestR, m_Surface, &DestR);

		if (!this->keySet[i].getIsActiveState())
		{
			//DestR.x = this->keySet[i].getButtonX();
			//DestR.y = this->keySet[i].getButtonY();
			//DestR.w = this->keySet[i].getButtonW();
			//DestR.h = this->keySet[i].getButtonH();

			SDL_FillRect(m_Surface, &this->keySet[i], SDL_MapRGB(m_Surface->format, 0, 0, 0));
			//SDL_BlitSurface(s_KeyboardDarkened, &DestR, m_Surface, &DestR);
		}
		else
		{
			//SDL_BlitSurface(s_Keyboard, &this->keySet[i], m_Surface, &keyboardPosition);
			//SDL_BlitSurface(s_Keyboard, &DestR, s_Keyboard, &keyboardPosition);
		}
	}
	
	////init switches debug
	//SDL_Color statRectColor = { 0, 255, 0 };
	////row 1
	//int xPos = keyboardPosition.x;
	//int yPos = keyboardPosition.y + 2;
	//for (size_t i = 1; i <= 10; ++i)
	//{
	//	SDL_Rect statRectSize = { xPos, yPos, 90, 55 };
	//	drawer.drawRect(statRectSize, statRectColor, m_Surface);
	//	xPos += 99;
	//}
	////row 2
	//xPos = keyboardPosition.x;
	//yPos = keyboardPosition.y + 75;
	//for (size_t i = 1; i <= 9; ++i)
	//{
	//	SDL_Rect statRectSize = { xPos, yPos, 90, 55 };
	//	drawer.drawRect(statRectSize, statRectColor, m_Surface);
	//	xPos += 99;
	//}
	////row 3
	//xPos = keyboardPosition.x + 100;
	//yPos = keyboardPosition.y + 147;
	//for (size_t i = 1; i <= 7; ++i)
	//{
	//	SDL_Rect statRectSize = { xPos, yPos, 90, 55 };
	//	drawer.drawRect(statRectSize, statRectColor, m_Surface);
	//	xPos += 99;
	//}

}

char Keyboard::handleEvents(SDL_Event* e)
{
	for (char i = 0; i < keySet.size(); ++i)
	{
		if (this->keySet[i].isSwitchOn(e) && this->keySet[i].getIsActiveState())
		{
			//debug
			//cout << keySet[i].getCharacter() << endl;
			this->keySet[i].setIsActiveState(false);
			return keySet[i].getCharacter();
		}
	}
	return 0;
}