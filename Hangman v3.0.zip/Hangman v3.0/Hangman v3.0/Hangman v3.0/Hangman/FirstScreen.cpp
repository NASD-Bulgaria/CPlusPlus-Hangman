#include "stdafx.h"
#include "FirstScreen.h"

FirstScreen::FirstScreen()
{}

FirstScreen::~FirstScreen()
{}

Button FirstScreen::getPlayButton(void)
{
	return this->playButton;
}

Button FirstScreen::getIncreaseCreditButton(void)
{
	return this->increaseCredit;
}

Button FirstScreen::getDecreseCreditButton(void)
{
	return this->decreseCredit;
}

void FirstScreen::init(Round& round)
{
	onEnter(round);
}

void FirstScreen::onEnter(Round& round)
{
	round.loadCredit();
	this->credit = round.getCredit();
	this->roundsList.clear();
	readRoundInfoFromFile();
}

void FirstScreen::readRoundInfoFromFile(void)
{
	ifstream readFromFile;
	readFromFile.open("resources/backups/lastTenGames.txt");

	string readed;
	double profitRead;

	if (readFromFile.is_open())
	{
		while (readFromFile >> readed >> profitRead)
		{
			stringstream sstr;									// Ignor unusifull numbers
			sstr << setprecision(3) << profitRead;

			readed += " " + sstr.str();
			this->roundsList.push_back(readed);
		}
	}
}

//string FirstScreen::getStringCredit(void)
//{
//	stringstream str;
//	str << fixed << setprecision(1) << this->credit;
//	string cr = str.str();
//	return cr;
//}

string FirstScreen::getStringToPrecDouble(double d)
{
	stringstream str;
	str << fixed << setprecision(1) << d;
	string cr = str.str();
	return cr;
}

void FirstScreen::increseCredit(Round& round)
{
	cout << "INSIDE" << endl;
	if (this->credit < 10.0)
	{
		//cout << "INSIDE" << endl;
		this->credit = 10.0;
		cout << this->credit;
	}
	else if (this->credit >= 10.0)
	{
		this->credit += 1.0;
		cout << this->credit;
	}
	if (this->credit > 100.0)
	{
		this->credit = 100.0;
	}
	if (this->credit < 0.0)
	{
		this->credit = 0.0;
	}
	round.setCredit(this->credit);
}

void FirstScreen::decreaseCredit(Round& round)
{
	cout << "INSIDE" << endl;
	if (this->credit >= 10)
	{
		this->credit -= 1;
	}
	if (this->credit < 10)
	{
		this->credit = 0;
	}
	if (this->credit > 100.0)
	{
		this->credit = 100.0;
	}
	else if (this->credit < 0.0)
	{
		this->credit = 0.0;
	}
	round.setCredit(this->credit);
}

bool FirstScreen::isPlayButtonActive(void)
{
	return (this->credit > 0);
}

void FirstScreen::DrawScreen(SDL_Surface* &m_Surface)
{
	drawer.SetFont(110, { 0, 0, 0 });
	drawer.drawText(250, 50, "The Hangman", m_Surface);

	//play button
	playButton.setButtonSpecs(540, 560, 180, 60);
	///test for buttons
	//SDL_Rect testRect = { 540, 560, 180, 60 };
	//SDL_Color testRectColor = { 0, 255, 0 };
	//drawer.drawRect(testRect, testRectColor, m_Surface);
	//play
	SDL_Color fontColor = { 255, 0, 0 };
	drawer.SetFont(70, fontColor);
	drawer.drawText(540, 560, "Play", m_Surface);

	//last ten games info
	fontColor = { 0, 0, 0 };
	drawer.SetFont(30, fontColor);
	int yPos = 210;
	for (size_t i = 0; i < roundsList.size(); ++i)
	{
		drawer.drawText(540, yPos, roundsList[i], m_Surface);
		yPos += 30;
	}

	//credit
	drawer.SetFont(60, fontColor);
	drawer.drawText(45, 245, "Credit", m_Surface);

	//credit value display TODO
	//int dummyCredit = 100;

	fontColor = { 255, 0, 0 };
	drawer.SetFont(60, fontColor);
	//drawer.drawText(82, 325, getStringCredit(), m_Surface);
	drawer.drawText(82, 325, getStringToPrecDouble(this->credit), m_Surface);

	///test +
	//statRectColor = { 0, 255, 0 };
	//statRectSize = { 210, 325, 30, 55 };
	//drawer.drawRect(statRectSize, statRectColor, m_Surface);
	//+
	increaseCredit.setButtonSpecs(210, 325, 30, 55);
	drawer.SetFont(60, fontColor);
	drawer.drawText(210, 325, "+", m_Surface);

	//test -
	//statRectSize = { 65, 325, 30, 55 };
	//drawer.drawRect(statRectSize, statRectColor, m_Surface);
	//-
	decreseCredit.setButtonSpecs(50, 325, 30, 55);
	drawer.SetFont(60, fontColor);
	drawer.drawText(50, 325, "-", m_Surface);
}
