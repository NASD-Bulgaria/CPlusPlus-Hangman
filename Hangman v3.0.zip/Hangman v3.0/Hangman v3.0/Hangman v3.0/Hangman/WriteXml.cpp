#include "stdafx.h"
#include "WriteXml.h"
#include <string>
#include <fstream>
#include <ctime>
#include <iostream>
#include <windows.h>


using namespace std;

WriteXml::WriteXml()
{
}


WriteXml::~WriteXml()
{
}

void WriteXml::newXml(Round& curentGame)
{
	string startTime = curentGame.getStartTime();
	string stopTime = curentGame.getStopTime();
	string playingTime = curentGame.getPlayingTime();
	double credit = curentGame.getCredit();
	double bidding = curentGame.getBid();
	double profit = curentGame.getEarning();
	double timeFactor = curentGame.getTimeFactor();

	//-------------------------------------------------------------------------------------------------------------------

	/*���� ������ �� �� ������� ��� ���������� �� ������ � ������������ ����� �� �� �������� �����*/
	string nameOfFile = "resources/backups/RoundsXMLs/Hangman_"; // adding name of game to name of file

	string nameOfMachine = getenv("COMPUTERNAME");
	nameOfFile += nameOfMachine + "_"; // adding name of PC to name of file

	// get time info for name of file
	time_t now = time(0);
	tm *ltm = localtime(&now);

	// adding data to name of file
	nameOfFile += to_string(ltm->tm_mday) + "_";
	nameOfFile += to_string(1 + ltm->tm_mon) + "_";
	nameOfFile += to_string(1900 + ltm->tm_year) + "_";

	// adding clock to name of file
	nameOfFile += to_string(ltm->tm_hour) + "_";
	nameOfFile += to_string(ltm->tm_min) + "_";
	nameOfFile += to_string(ltm->tm_sec);

	// adding ".xml" to file name
	nameOfFile += ".xml";


	//-------------------------------------------------------------------------------------------------------------------

	// createin file
	ofstream writeFile(nameOfFile.c_str(), ios::out);

	if (writeFile.is_open())
	{
		writeFile << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" << endl;
		writeFile << "<GAME>" << endl;
		writeFile << "\t<START_TIME>" << startTime << "</START_TIME>" << endl;
		writeFile << "\t<FINAL_TIME>" << stopTime << "</FINAL_TIME>" << endl;
		writeFile << "\t<TIME_FOR_PLAY>" << playingTime << "</TIME_FOR_PLAY>" << endl;
		writeFile << "\t<STARTING_CREDIT>" << credit << "</STARTING_CREDIT>" << endl;
		writeFile << "\t<BIDDING>" << bidding << "</BIDDING>" << endl;
		writeFile << "\t<PROFIT>" << profit << "</PROFIT>" << endl;
		writeFile << "\t<COEFFICIENT>" << timeFactor << "</COEFFICIENT>" << endl;
		writeFile << "</GAME>" << endl;

		writeFile.close();
	}
	else
	{
		cout << "Error: File is not created!" << endl;
	}

}