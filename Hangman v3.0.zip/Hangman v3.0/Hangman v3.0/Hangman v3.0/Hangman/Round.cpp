#include "stdafx.h"
#include "Round.h"

using namespace std;

Round::Round()
{
}


Round::~Round()
{
}

//setters
void Round::setStartTime()
{
	this->startTime = getCurentTime();
}

void Round::setStopTime()
{
	this->stopTime = getCurentTime();
	setPlayingTime();
}

void Round::setPlayingTime()
{

	//get time info

	string startHours = this->startTime.substr(10, 2);
	string startMinuets = this->startTime.substr(13, 2);
	string startSeconds = this->startTime.substr(16, 2);

	string finalHours = this->stopTime.substr(10, 2);
	string finalMinuets = this->stopTime.substr(13, 2);
	string finalSeconds = this->stopTime.substr(16, 2);

	//convert to int

	int startHoursInt = stoi(startHours);
	int startMinuetsInt = stoi(startMinuets);
	int startSecondsInt = stoi(startSeconds);

	int finalHoursInt = stoi(finalHours);
	int finalMinuetsInt = stoi(finalMinuets);
	int finalSecondsInt = stoi(finalSeconds);

	// calculate

	if (finalHoursInt == 0 && startHoursInt == 23)
	{
		finalHoursInt += 24;
	}

	int startSecondsAll = (startHoursInt * 3600) + (startMinuetsInt * 60) + startSecondsInt;
	int finalSecondsAll = (finalHoursInt * 3600) + (finalMinuetsInt * 60) + finalSecondsInt;

	int difrentsBetweenMinets = (finalSecondsAll - startSecondsAll) / 60;
	int difrentsBetweenSeconds = (finalSecondsAll - startSecondsAll) % 60;

	stringstream addZerosToSeconds;
	stringstream addZerosToMinuets;
	addZerosToSeconds << setfill('0') << setw(2) << difrentsBetweenSeconds;				// add zeros for seconds from 0 to 9;
	addZerosToMinuets << setfill('0') << setw(2) << difrentsBetweenMinets;				// add zeros for seconds from 0 to 9;

	// real sets
	this->playingTime = addZerosToMinuets.str() + ":" + addZerosToSeconds.str();
}

void Round::setCredit(double credit)
{
	this->credit = credit;
}

void Round::setBid(double bid)
{
	this->bid = bid;
}

void Round::setEarning(double earning)
{
	if (earning < 0)
	{
		earning = 0;
	}
	this->earning = earning;
}

void Round::setTimeFactor(double timeFactor)
{
	this->timeFactor = timeFactor;
}


//getters

string Round::getStartTime()
{
	return this->startTime;
}

string Round::getStopTime()
{
	return this->stopTime;
}

double Round::getCredit(void)
{
	return this->credit;
}

double Round::getBid(void)
{
	return this->bid;
}

double Round::getEarning(void)
{
	return this->earning;
}
string Round::getPlayingTime(void)
{
	return this->playingTime;
}

double Round::getTimeFactor()
{
	return this->timeFactor;
}

string Round::getCurentTime()
{
	time_t now = time(0);
	tm *ltm = localtime(&now);

	string hours = to_string(ltm->tm_hour);
	if (hours.size() < 2)
	{
		hours = "0" + hours;
	}
	//cout << hours << endl;

	string minutes = to_string(ltm->tm_min);
	if (minutes.size() < 2)
	{
		minutes = "0" + minutes;
	}
	//cout << minutes << endl;

	string curentTime;
	curentTime += to_string(ltm->tm_mday) + ".";
	curentTime += to_string(1 + ltm->tm_mon) + ".";
	curentTime += to_string(1900 + ltm->tm_year) + " ";
	curentTime += hours + ":";
	curentTime += minutes + ":";
	curentTime += to_string(ltm->tm_sec);

	return curentTime;
}

//--------------------------------------------------------

void Round::init(void)
{
	loadCredit();
	this->bid = 0.0;
	this->earning = 0.0;
	this->timeFactor = 0.0;
}

void Round::saveCredit(void)
{
	ofstream fileStream;
	fileStream.open("resources/backups/credit.txt");
	if (fileStream.is_open())
	{
		fileStream << this->credit;
	}
	fileStream.close();
}

void Round::loadCredit(void)
{
	ifstream fileStream;
	fileStream.open("resources/backups/credit.txt");
	if (fileStream.is_open())
	{
		fileStream >> this->credit;
	}
	fileStream.close();
}

