#include "stdafx.h"
#include "ThirdScreen.h"


ThirdScreen::ThirdScreen()
{
}


ThirdScreen::~ThirdScreen()
{
}

bool ThirdScreen::getWinning(void)
{
	return this->winning;
}

bool ThirdScreen::getLoosing(void)
{
	return this->loosing;
}

bool ThirdScreen::getRoundRunning(void)
{
	return this->roundRunning;
}

double ThirdScreen::getCredit(void)
{
	return this->credit;
}

double ThirdScreen::getBid(void)
{
	return this->bid;
}

double ThirdScreen::getEarning(void)
{
	return this->earning;
}

unsigned int ThirdScreen::getTimer(void)
{
	return this->timer;
}

void ThirdScreen::init(void)
{
	
}

string ThirdScreen::getStringToPrecDouble(double d)
{
	stringstream str;
	str << fixed << setprecision(1) << d;
	string cr = str.str();
	return cr;
}

void ThirdScreen::saveRoundInfo(Round& r)
{
	this->roundsList.push_back(r);
	if (this->roundsList.size() > 10)
	{
		this->roundsList.pop_front();
	}
}

void ThirdScreen::writeRoundInfoToFile(void)
{
	ofstream writeToFileLastTen;

	writeToFileLastTen.open("resources/backups/lastTenGames.txt");

	if (writeToFileLastTen.is_open())
	{
		for (auto it = this->roundsList.begin(); it != this->roundsList.end(); it++)
		{
			writeToFileLastTen << it->getPlayingTime() << "\t" << getStringToPrecDouble(it->getEarning()) << endl;
		}
	}
	writeToFileLastTen.close();
}

void ThirdScreen::genRandTimeWindow(void)
{
	srand(time(0));
	int randomTime = rand() % 3 + 1;

	switch (randomTime)
	{
	case 1: randomTime = 120; break;
	case 2: randomTime = 180; break;
	case 3: randomTime = 240; break;
	}

	this->timer = randomTime;
	this->timeWindow = randomTime;
}



void ThirdScreen::onEnter(Round& round, string word)
{
	//saving round's start time
	round.setStartTime();

	this->credit = round.getCredit();
	//round.setBid(0);
	this->bid = round.getBid();
	this->timer = 0;
	this->playerLives = 7;
	this->guessWord = "";
	this->currentWord = word;
	this->roundRunning = true;
	this->winning = false;
	this->loosing = false;
	//creating visibility chars vector
	//this->visibleChars.reserve(word.size());
	//this->visibleChars.assign(word.size(), 0);
	//visibleChars[0] = 1;
	//visibleChars[word.size()-1] = 1;
	//vector<char> data(currentWord.begin(), currentWord.end());
	this->guessWord.push_back(word[0]);
	this->guessWord.append(word.size() - 2, '*');
	this->guessWord.push_back(word[word.size() - 1]);
	this->unknownChars = guessWord.length() - 2;

	//debug
	//for (int i = 0; i < visibleChars.size(); ++i)
	//{
	//	cout << visibleChars[i] << " ";
	//}

	stopwatch = stopwatchInit;
	genRandTimeWindow();
	keyboard = keyboardInit;
	keyboard.init();
}

void ThirdScreen::onExit(Round& round)
{
	//saving round's stop time
	round.setStopTime();
	round.setPlayingTime();
	
	timeFactor = 0.0025*(300 - timeWindow);
	round.setTimeFactor(timeFactor);

	earning = bid*timeFactor;
	round.setEarning(earning);

	saveRoundInfo(round);
	writeRoundInfoToFile();
}

void ThirdScreen::runRound(char userGuess)
{
	if (roundRunning && userGuess >= 'a' && userGuess <= 'z')
	{
		//cout << "roundRunning: " << roundRunning << endl;
		//char userGuess = 0;
		bool isAnswerCorrect = false;
		//	guessedLetters[i] = userGuess;
		//i++;
		for (size_t pos = 1; pos < guessWord.length()-1; pos++)
		{
			//cout << "userGuess: " << userGuess << endl;
			//cout << "guessWord[pos]: " << guessWord[pos] << endl;
			if (userGuess == currentWord[pos])
			{
				//cout << "one letter" << endl;
				guessWord[pos] = userGuess;
				isAnswerCorrect = true;
				//cout << "isAnswerCorrect: " << isAnswerCorrect << endl;
				--unknownChars;
			}
			else
			{
				//isAnswerCorrect = false;
			}
		}
		//cout << "unknownChars: " << unknownChars << endl;
		//cout << "playerLives: " << playerLives << endl;
		if (!isAnswerCorrect)
		{
			--playerLives;
		}
		//cout << "playerLives: " << playerLives << endl;
		
	}
	if (roundRunning && (unknownChars == 0))
	{
		roundRunning = false;
		winning = true;
	}
	if (roundRunning && this->playerLives == 0)
	{
		roundRunning = false;
		loosing = true;
	}
	cout << unknownChars << endl;

	//if (timer == 0) { cout << "You lose" << endl; stopwatch.stop(); }
	//if (playerLives <= 0) { cout << "You lose" << endl; stopwatch.stop(); }
	//if (guessWord == currentWord) { cout << "You win" << endl; }
}

void ThirdScreen::DrawScreen(SDL_Surface* m_Surface)
{
	this->stopwatch.start(this->timer);
	if (this->timer == 0)
	{
		roundRunning = false;
		loosing = true;
	}

	//bet sign
	SDL_Color fontColor = { 0, 0, 0 };
	drawer.SetFont(60, fontColor);
	drawer.drawText(100, 50, "Your Bet", m_Surface);

	//bet value display
	drawer.SetFont(60, fontColor);
	drawer.drawText(400, 50, getStringToPrecDouble(this->bid), m_Surface);

	//timer sign
	fontColor = { 0, 0, 0 };
	drawer.SetFont(60, fontColor);
	drawer.drawText(600, 50, "Timer", m_Surface);

	//timer value display
	fontColor = { 255, 0, 0 };
	drawer.SetFont(60, fontColor);
	drawer.drawText(800, 50, std::to_string(this->timer), m_Surface);

	//word
	//writeWord(m_Surface);
	fontColor = { 0, 0, 0 };
	drawer.SetFont(80, fontColor);
	drawer.drawText(250, 260, guessWord, m_Surface);

	//keyboard
	keyboard.draw(m_Surface);
}