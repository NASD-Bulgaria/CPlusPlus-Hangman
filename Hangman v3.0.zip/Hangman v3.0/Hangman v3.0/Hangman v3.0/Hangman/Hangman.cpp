#include "stdafx.h"
#include "GameHandler.h"

int _tmain(int argc, _TCHAR* argv[])
{
	GameHandler Hangman;
	Hangman.init();
	Hangman.run();

	return 0;
}

