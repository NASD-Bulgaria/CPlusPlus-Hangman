#include "stdafx.h"
#include "XStr.h"


XStr::XStr(const char* const toTranscode)
{
	fUnicodeForm = XMLString::transcode(toTranscode);
}


XStr::~XStr()
{
	XMLString::release(&fUnicodeForm);
}

const XMLCh* XStr::unicodeForm() const
{
	return this->fUnicodeForm;
}