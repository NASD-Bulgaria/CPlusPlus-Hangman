// Statistics.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "FromXmlToVector.h"
#include "allStatistics.h"
#include "C:/boost/boost_1_58_0/boost/date_time/gregorian/gregorian.hpp"

#include <sstream>
#include <ctime>
#include <string>

#include <iomanip>
#include <locale>

using namespace std;
using namespace boost;
using namespace boost::filesystem;
namespace bdt = boost::gregorian;

void menu(FromXmlToVector, FromXmlToVector, FromXmlToVector);
int calcolateDates(int*);
bool checkDay(int);
bool checkMonth(int);
bool checkYear(int);
bool validPeriod(const int*);


int main(int argc, _TCHAR* argv[])
{
	FromXmlToVector searchByDay;
	FromXmlToVector searchByMount;
	FromXmlToVector searchByPeriod;

	menu(searchByDay, searchByMount, searchByPeriod);

	return 0;
}




void menu(FromXmlToVector searchByDay, FromXmlToVector searchByMount, FromXmlToVector searchByPeriod)
{
	bool exitVal = false;
	string pathString;

	cout << "Enter the path: ";
	getline(cin, pathString);

	do
	{
		cout << "==========================================\n";
		cout << "1. Dayly.\n";
		cout << "2. Monthly.\n";
		cout << "3. Random period.\n";
		cout << "4. Exit.\n";
		cout << "==========================================\n";
		cout << "\nChoose: ";

		int choice;
		scanf("%d", &choice);
		
		string date;
		
		switch (choice)
		{
		case 1:
		{
			int day, month, year;
			do
			{
				cout << "Enter a day for searching: ";
				cin >> day;
			} while (!checkDay(day));
			do
			{
				cout << "Enter a number of month for searching: ";
				cin >> month;
			} while (!checkMonth(month));
			do
			{
				cout << "Enter a year for searching: ";
				cin >> year;
			} while (!checkYear(year));

			date = to_string(day) + "_" + to_string(month) + "_" + to_string(year);

			
			searchByDay.setPath(pathString);
			searchByDay.calculateDailyStatistics(date);
			
			allStatistics dayStatistics;
			dayStatistics.writeCsvFileDaily(searchByDay);
			searchByDay.clearVec();

			break;
		}
		case 2:
		{
			int month, year;
			do
			{
				cout << "Enter a number of month for searching: ";
				cin >> month;
			} while (!checkMonth(month));
			do
			{
				cout << "Enter a year for searching: ";
				cin >> year;
			} while (!checkYear(year));
			date = to_string(month) + "_" + to_string(year);

			searchByMount.setPath(pathString);
			searchByMount.calculateMounthlyStatistics(date);

			allStatistics monthlyStatistics;
			monthlyStatistics.writeCsvFileMonthly(searchByMount);
			searchByMount.clearVec();

			break;
		}
		case 3:
		{
				  int daySt, monthSt, yearSt, dayLast, montLast, yearLast;
				  int firstAndLast[6];
				  // Enter starting data for period
				  do
				  {
					  do
					  {
						  cout << "Enter firts day for searching: " << endl;
						  cout << "Enter a day : ";
						  cin >> daySt;
					  } while (!checkDay(daySt));

					  do
					  {
						  cout << "Enter a number of month : ";
						  cin >> monthSt;
					  } while (!checkMonth(monthSt));

					  do
					  {
						  cout << "Enter a year : ";
						  cin >> yearSt;
					  } while (!checkYear(yearSt));

					  // Enter last data for period
					  do
					  {
						  cout << "Enter last day for searching: " << endl;
						  cout << "Enter a day : ";
						  cin >> dayLast;
					  } while (!checkDay(dayLast));

					  do
					  {
						  cout << "Enter a number of month : ";
						  cin >> montLast;
					  } while (!checkMonth(montLast));

					  do
					  {
						  cout << "Enter a year : ";
						  cin >> yearLast;
					  } while (!checkYear(yearLast));

					  firstAndLast[0] = daySt;
					  firstAndLast[1] = monthSt;
					  firstAndLast[2] = yearSt;
					  firstAndLast[3] = dayLast;
					  firstAndLast[4] = montLast;
					  firstAndLast[5] = yearLast;

				  } while (!validPeriod(firstAndLast));

				  searchByPeriod.setPath(pathString);
				  searchByPeriod.createPeriod(firstAndLast);

				  allStatistics periodStatistics;
				  periodStatistics.setPeriodDays(calcolateDates(firstAndLast));
				  periodStatistics.writeCsvFileForPeriod(searchByPeriod);
				  searchByPeriod.clearVec();

				break;
		}
		case 4:
			exitVal = true;
			break;
		default:
			cout << "Wrong choice.\n";
			break;
		}
		choice = 0;
	} while (!exitVal);
}

int calcolateDates(int* firstAndLast)
{
	bdt::date firstDay(bdt::date(firstAndLast[2], firstAndLast[1], firstAndLast[0]));
	bdt::date lastDay(bdt::date(firstAndLast[5], firstAndLast[4], firstAndLast[3]));
	bdt::date_period range(firstDay, lastDay);
	return  range.length().days();
}

bool checkDay(int day)
{
	return day > 0 && day < 32;
}

bool checkMonth(int month)
{
	return month > 0 && month < 13;
}

bool checkYear(int year)
{
	time_t now = time(0);
	tm *ltm = localtime(&now);
	return year > 2014 && year <= (ltm->tm_year + 1900);
}

bool validPeriod(const int* firstAndLast)
{
	bool isCorrectly = true;
	int firstDate = (firstAndLast[2] * 365) + (firstAndLast[1] * 30) + firstAndLast[0];
	int lastDate = (firstAndLast[5] * 365) + (firstAndLast[4] * 30) + firstAndLast[3];
	if (firstDate >= lastDate)
	{
		isCorrectly = false;
	}
	return isCorrectly;
}