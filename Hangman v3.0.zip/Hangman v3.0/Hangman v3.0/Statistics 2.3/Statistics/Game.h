#pragma once
#include "stdafx.h"

class Game
{
public:
	Game();
	Game(struct tm, struct tm, struct tm, double, double, double, double);
	virtual ~Game();

	struct tm getStartTime(void);
	void setStartTime(struct tm);

	struct tm getStopTime(void);
	void setStopTime(struct tm);

	struct tm getPlayingTime(void);
	void setPlayingTime(struct tm);

	double getCredit(void);
	void setCredit(double);

	double getBidding(void);
	void setBidding(double);

	double getEarning(void);
	void setEarning(double);

	double getTimeFactor(void);
	void setTimeFactor(double);

	void print()const;
private:
	struct tm startTime;
	struct tm stopTime;
	struct tm playingTime;
	double credit;
	double bidding;
	double earning;
	double timeFactor;
};

