#pragma once

#include <sstream>
#include <ctime>
#include <string>

#include <iomanip>
#include <locale>

using namespace std;
using namespace boost;
using namespace boost::filesystem;

class FromXmlToVector
{
public:
	FromXmlToVector();
	~FromXmlToVector();

	void selectiveSearch(const std::string&);
	int parseXML(char*);
	void traversing(DOMDocument*);

	void setPath(string);
	
	void calculateDailyStatistics(string&);
	void calculateMounthlyStatistics(string&);
	void calculatePeriodStatistics();

	static void reverseSlashes(string&);
	vector<Game> getVector()const;
	vector<string> getDatesForPeriod()const;

	void createPeriod(int[]);
	void clearVec();
	void print()const;

private:
	vector<Game> gamesStatistics;
	vector<string> datesForPeriod;
	path searchPath;
};

