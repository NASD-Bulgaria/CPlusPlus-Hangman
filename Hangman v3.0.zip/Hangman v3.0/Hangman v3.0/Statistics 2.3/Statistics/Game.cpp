#include "stdafx.h"
#include "Game.h"

using namespace std;

Game::Game()
{
}

Game::Game(struct tm startTime, struct tm stopTime, struct tm playingTime, double credit, double bidding, double earning, double timeFactor)
{
	setStartTime(startTime);
	setStopTime(stopTime);
	setPlayingTime(playingTime);
	setCredit(credit);
	setBidding(bidding);
	setEarning(earning);
	setTimeFactor(timeFactor);
}

Game::~Game()
{
}

struct tm Game::getStartTime(void)
{
	return this->startTime;
}
void Game::setStartTime(struct tm startTime)
{
	this->startTime = startTime;
}
struct tm Game::getStopTime(void)
{
	return this->stopTime;
}
void Game::setStopTime(struct tm stopTime)
{
	this->stopTime = stopTime;
}
struct tm Game::getPlayingTime(void)
{
	return this->playingTime;
}
void Game::setPlayingTime(struct tm playingTime)
{
	this->playingTime = playingTime;
}
double Game::getCredit(void)
{
	return this->credit;
}
void Game::setCredit(double credit)
{
	this->credit = credit;
}
double Game::getBidding(void)
{
	return this->bidding;
}
void Game::setBidding(double bidding)
{
	this->bidding = bidding;
}
double Game::getEarning(void)
{
	return this->earning;
}
void Game::setEarning(double earning)
{
	this->earning = earning;
}
double Game::getTimeFactor(void)
{
	return this->timeFactor;
}
void Game::setTimeFactor(double timeFactor)
{
	this->timeFactor = timeFactor;
}

void Game::print()const
{
	cout << startTime.tm_mday << "." << (1 + startTime.tm_mon) << "." << (1900 + startTime.tm_year) << " " << startTime.tm_hour << ":" << startTime.tm_min <<
		":" << startTime.tm_sec << endl;
	cout << stopTime.tm_mday << "." << (1 + stopTime.tm_mon) << "." << (1900 + stopTime.tm_year) << " " << stopTime.tm_hour << ":" << stopTime.tm_min <<
		":" << stopTime.tm_sec << endl;
	cout << playingTime.tm_min << ":" << playingTime.tm_sec << endl;
	cout << credit << endl;
	cout << bidding << endl;
	cout << earning << endl;
	cout << timeFactor << endl;
}