#pragma once
class XStr
{
public:
	XStr(const char* const);
	~XStr();

	const XMLCh* unicodeForm() const;

private:
	XMLCh* fUnicodeForm;
};

