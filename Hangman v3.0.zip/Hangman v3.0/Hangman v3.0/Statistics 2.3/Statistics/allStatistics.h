#pragma once

#include "Game.h"
#include "FromXmlToVector.h"
#include <vector>
#include <map>

using namespace boost::filesystem;
using namespace std;

class allStatistics
{
public:
	allStatistics();
	~allStatistics();

	// for daily statistics

	void writeCsvFileDaily(FromXmlToVector);
	void gameByHour(vector<Game>&, int*);
	void playTime(vector<Game>&, vector <string>* , struct tm* , struct tm* );
	void profitPerPlayHour(double*, double*, struct tm*);
	void profitPerHourForDay(double*, double*);

	// for mounthly statistics
	
	void writeCsvFileMonthly(FromXmlToVector);
	void gameByDaysMonthly(vector <Game>&, int*);
	void monthProfit(double*, double*);
	void profitByHourForMont(vector <Game>&, double*, double*);

	// for period statistics
	void writeCsvFileForPeriod(FromXmlToVector);
	void gameByDaysPeriod(vector <Game>&, map<string, int>&);
	void balanceForDayFromPeriod(map<string, vector <Game> >&, map<string, double>&, vector <Game>&);
	void profitForPeriod(map<string, double>&, double*);
	void setPeriodDays(int);
	void profitPerHoursPeriod(double*, double*);

	// for two or more 
	void balance(vector<Game>&, double*);										//use for all statistics
	void casinoProfit(vector<Game>&, double*);									//use for all statistics
	void realPlayTimeForMonthAndPeriod(struct tm*, map<string, struct tm>&);	//use for month and period
	void profitByPlayHourForMontAndPeriod(struct tm*, double*, double*);		//use for month and period
	void realPlayGameTime(vector <Game>&, struct tm&, string*);					//use for month and period

private:
	int periodDays;
};

