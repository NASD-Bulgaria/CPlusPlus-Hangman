#pragma once
class StrToX
{
public:
	StrToX(const XMLCh* const );
	~StrToX();

	const char* localForm() const;
private:
	char*   fLocalForm;
};

