#include "stdafx.h"
#include "StrToX.h"


StrToX::StrToX(const XMLCh* const toTranscode)
{
	fLocalForm = XMLString::transcode(toTranscode);
}


StrToX::~StrToX()
{
	XMLString::release(&fLocalForm);
}

const char* StrToX::localForm() const
{
	return fLocalForm;
}
