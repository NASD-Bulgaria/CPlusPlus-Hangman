#include "stdafx.h"
#include "FromXmlToVector.h"
#include "XStr.h"
#include "StrToX.h"


FromXmlToVector::FromXmlToVector()
{
}


FromXmlToVector::~FromXmlToVector()
{
}

void FromXmlToVector::calculateDailyStatistics(string& date)
{
	selectiveSearch(date);
}

void FromXmlToVector::calculateMounthlyStatistics(string& date)
{
	selectiveSearch(date);
}

void FromXmlToVector::calculatePeriodStatistics()
{
	for (int i = 0; i < this->datesForPeriod.size(); i++)
	{
		selectiveSearch(this->datesForPeriod[i]);
	}
}

void FromXmlToVector::reverseSlashes(string& str)
{
	std::replace(str.begin(), str.end(), '\\', '/');
}

void FromXmlToVector::selectiveSearch(const std::string& searchedPeriod)
{
	recursive_directory_iterator dir(this->searchPath), end;
	while (dir != end)
	{
		if (dir->path().filename().extension() == ".xml")
		{
			string fileName = dir->path().filename().replace_extension().string();
			size_t found = fileName.find(searchedPeriod);
			if (found != std::string::npos)
			{
				string temp = dir->path().string();
				reverseSlashes(temp);
				char* xmlFile = (char*)temp.c_str();
				parseXML(xmlFile);
			}
		}

		++dir;
	}
}

int FromXmlToVector::parseXML(char* xmlFile)
{
	try {
		XMLPlatformUtils::Initialize();
	}
	catch (const XMLException& toCatch) {
		char* message = XMLString::transcode(toCatch.getMessage());
		cout << "Error during initialization! :\n"
			<< message << "\n";
		XMLString::release(&message);
		return 1;
	}

	XercesDOMParser* parser = new XercesDOMParser();
	parser->setValidationScheme(XercesDOMParser::Val_Always);
	parser->setDoNamespaces(true);    // optional

	ErrorHandler* errHandler = (ErrorHandler*) new HandlerBase();
	parser->setErrorHandler(errHandler);

	try {
		parser->parse(xmlFile);
		DOMDocument* doc = parser->getDocument();

		traversing(doc);	// traversing xml document
	}
	catch (const XMLException& toCatch) {
		char* message = XMLString::transcode(toCatch.getMessage());
		cout << "Exception message is: \n"
			<< message << "\n";
		XMLString::release(&message);
		return -1;
	}
	catch (const DOMException& toCatch) {
		char* message = XMLString::transcode(toCatch.msg);
		cout << "Exception message is: \n"
			<< message << "\n";
		XMLString::release(&message);
		return -1;
	}
	catch (...) {
		cout << "Unexpected Exception \n";
		return -1;
	}

	delete parser;
	delete errHandler;
	return 0;
}

void FromXmlToVector::traversing(DOMDocument* doc)
{
	const XMLSize_t gameStat = doc->getElementsByTagName(XStr("GAME").unicodeForm())->getLength();

	DOMNodeList* startTimeList = doc->getElementsByTagName(XStr("START_TIME").unicodeForm());
	DOMNodeList* stopTimeList = doc->getElementsByTagName(XStr("FINAL_TIME").unicodeForm());
	DOMNodeList* playingTimeList = doc->getElementsByTagName(XStr("TIME_FOR_PLAY").unicodeForm());
	DOMNodeList* creditList = doc->getElementsByTagName(XStr("STARTING_CREDIT").unicodeForm());
	DOMNodeList* biddingList = doc->getElementsByTagName(XStr("BIDDING").unicodeForm());
	DOMNodeList* earningList = doc->getElementsByTagName(XStr("PROFIT").unicodeForm());
	DOMNodeList* timeFactorList = doc->getElementsByTagName(XStr("COEFFICIENT").unicodeForm());

	for (size_t i = 0; i < gameStat; ++i)
	{
		DOMNode* startTime = startTimeList->item(i);
		DOMNode* stopTime = stopTimeList->item(i);
		DOMNode* playingTime = playingTimeList->item(i);
		DOMNode* credit = creditList->item(i);
		DOMNode* bidding = biddingList->item(i);
		DOMNode* earning = earningList->item(i);
		DOMNode* timeFactor = timeFactorList->item(i);


		string sStartTime = StrToX(startTime->getTextContent()).localForm();

		struct tm tmStart;
		istringstream ss(sStartTime);
		ss >> get_time(&tmStart, "%d.%m.%Y %H:%M:%S");

		string sStopTime = StrToX(stopTime->getTextContent()).localForm();

		struct tm tmStop;
		istringstream ss2(sStopTime);
		ss2 >> get_time(&tmStop, "%d.%m.%Y %H:%M:%S");

		string sPlayingTime = StrToX(playingTime->getTextContent()).localForm();

		struct tm tmPlayingTime;
		istringstream ss3(sPlayingTime);
		ss3 >> get_time(&tmPlayingTime, "%M:%S");

		double dCredit = stod(StrToX(credit->getTextContent()).localForm());
		double dBidding = stod(StrToX(bidding->getTextContent()).localForm());
		double dEarning = stod(StrToX(earning->getTextContent()).localForm());
		double dTimeFactor = stod(StrToX(timeFactor->getTextContent()).localForm());



		Game game(tmStart, tmStop, tmPlayingTime, dCredit, dBidding, dEarning, dTimeFactor);

		this->gamesStatistics.push_back(game);
	}

}

vector<Game> FromXmlToVector::getVector()const
{
	return this->gamesStatistics;
}

vector<string> FromXmlToVector::getDatesForPeriod()const
{
	return this->datesForPeriod;
}

void FromXmlToVector::createPeriod(int firstAndLast[])
{
	int daySt = firstAndLast[0];
	int	monthSt = firstAndLast[1];
	int yearSt = firstAndLast[2];
	int dayLast = firstAndLast[3];
	int montLast = firstAndLast[4];
	int yearLast = firstAndLast[5];

	while ((daySt != dayLast + 1) || (monthSt != montLast) || (yearSt != yearLast))
	{
		string tempData = to_string(daySt) + "_" + to_string(monthSt) + "_" + to_string(yearSt);
		datesForPeriod.push_back(tempData);

		daySt++;

		if (daySt > 31)
		{
			daySt = 1;
			monthSt++;
		}

		if (monthSt > 12)
		{
			monthSt = 1;
			yearSt++;
		}
	}
	calculatePeriodStatistics();
}

void FromXmlToVector::setPath(string pathString)
{
	reverseSlashes(pathString);
	path pathPath = pathString;
	this->searchPath = pathPath;
}

void FromXmlToVector::clearVec()
{
	this->gamesStatistics.clear();
	this->datesForPeriod.clear();
}