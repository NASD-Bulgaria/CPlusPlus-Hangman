#include "stdafx.h"
#include "allStatistics.h"
#include <fstream>
#include <map>
#include <iterator>

allStatistics::allStatistics()
{
}


allStatistics::~allStatistics()
{
}
//-------------------------------------------------------------------------------------------------------------------------------------------------
/*Daily statistic starts here*/
//-------------------------------------------------------------------------------------------------------------------------------------------------
void allStatistics::writeCsvFileDaily(FromXmlToVector oneDay)
{
	vector<Game> gameForOneDay = oneDay.getVector();  // hold all games for day

	int hours[24] = { 0 };
	gameByHour(gameForOneDay, hours);
	//-----------------------------------------------------------------------------------------------------------------------------------------
	vector <string> gameRealExpectRatio;  // ratio between real and expect game duration
	struct tm realPlayTime;
	struct tm expectPlayTime;
	playTime(gameForOneDay, &gameRealExpectRatio, &realPlayTime, &expectPlayTime);

	//-----------------------------------------------------------------------------------------------------------------------------------------
	double balanceDouble = 0.0;  // ratio between bid and earning
	balance(gameForOneDay, &balanceDouble);

	//-----------------------------------------------------------------------------------------------------------------------------------------
	double profitForCasinoDay = 0.0; // hold profit for all day
	casinoProfit(gameForOneDay, &profitForCasinoDay);

	//-----------------------------------------------------------------------------------------------------------------------------------------
	double profitPerPlayHourDouble = 0.0; // hold profit for play hour
	profitPerPlayHour(&profitForCasinoDay, &profitPerPlayHourDouble, &realPlayTime);

	//-----------------------------------------------------------------------------------------------------------------------------------------
	double profitPerHourForDayDouble = 0.0; // hold profit for astronomic day
	profitPerHourForDay(&profitForCasinoDay, &profitPerHourForDayDouble);

	//-----------------------------------------------------------------------------------------------------------------------------------------
	ofstream dayStatistic;
	dayStatistic.open("Statistic for a day.csv", ios::out);

	if (dayStatistic.is_open())
	{
		dayStatistic << "Games; by hour:" << endl;
		for (int i = 0; i < 24; i++)
		{
			dayStatistic << "Between ;" << i << " and " << i + 1 << ";" << hours[i] << ";" << endl;
		}
		dayStatistic << endl;

		dayStatistic << "Duration:" << endl;
		for (int i = 0; i < gameRealExpectRatio.size(); i++)
		{
			dayStatistic << "Real  /;" << "Expect;" << gameRealExpectRatio[i] << endl;
		}
		dayStatistic << endl;

		dayStatistic << "Statistic; for full; day:" << endl;
		dayStatistic << "bid /;" << "profit ;1/" << setprecision(4) << balanceDouble << endl;
		dayStatistic << endl;
		dayStatistic << "Profit for;" << "day;" << profitForCasinoDay << endl;
		dayStatistic << endl;
		dayStatistic << "Play time;" << ";" << to_string(realPlayTime.tm_min) << ":" << to_string(realPlayTime.tm_sec) << endl;
		dayStatistic << endl;
		dayStatistic << "Profit per;" << "play hour;" << profitPerPlayHourDouble << endl;
		dayStatistic << endl;
		dayStatistic << "Profit per;" << "hour;" << profitPerHourForDayDouble << endl;

		dayStatistic.close();
		cout << "File is successfully created!" << endl;
	}
	else
	{
		cout << "File is not created!" << endl;
	}
}


void allStatistics::gameByHour(vector <Game>& gameForOneDay,int* hours) // only for day statistic
{
	for (int i = 0; i < gameForOneDay.size(); i++)
	{
		hours[gameForOneDay[i].getStartTime().tm_hour] ++;
	}
}

// only for day statistic
void allStatistics::playTime(vector<Game>& gameForOneDay, vector <string>* gameRealExpectRatio, struct tm* realPlayTime, struct tm* expectPlayTime)			//����������� �/� �������� � �������������� ����� - ���� � �� ����� ���� �� �������
{
	int minReal = 0, secReal = 0, expPalyTime = 0, minRealTemp = 0, secRealTemp = 0, expPalyTimeTemp = 0;

	for (int i = 0; i < gameForOneDay.size(); i++)
	{
		minReal += gameForOneDay[i].getPlayingTime().tm_min;
		secReal += gameForOneDay[i].getPlayingTime().tm_sec;

		minRealTemp += gameForOneDay[i].getPlayingTime().tm_min;
		secRealTemp += gameForOneDay[i].getPlayingTime().tm_sec;

		if (secReal > 59)
		{
			secReal = secReal % 60;
			minReal++;
		}
		
		if (gameForOneDay[i].getTimeFactor() == 0.45)
		{
			expPalyTime += 2;
			expPalyTimeTemp += 2;
		}
		else if (gameForOneDay[i].getTimeFactor() == 0.3)
		{
			expPalyTime += 3;
			expPalyTimeTemp += 3;
		}
		else
		{
			expPalyTime += 4;
			expPalyTimeTemp += 4;
		}

		double realTimeSeconds = (minRealTemp * 60) + secRealTemp;
		double expectTimeSeconds = expPalyTimeTemp * 60;

		minRealTemp = 0;
		secRealTemp = 0;
		expPalyTimeTemp = 0;

		int roundingRatio = expectTimeSeconds / realTimeSeconds;

		gameRealExpectRatio->push_back("1 to " + to_string(roundingRatio));
	}

	realPlayTime->tm_min = minReal;
	realPlayTime->tm_sec = secReal;

	expectPlayTime->tm_min = expPalyTime;
}

void allStatistics::balance(vector<Game>& gameForOneDay, double* balanceDouble) // for all statistics
{
	double bid = 0, profit = 0;

	for (int i = 0; i < gameForOneDay.size(); i++)
	{
		bid += gameForOneDay[i].getBidding();
		profit += gameForOneDay[i].getEarning();
	}
	if (profit == 0)
	{
		profit = 1;
	}

	if (gameForOneDay.size() != 0)
	{
		*balanceDouble = bid / profit;
	}
	else
	{
		*balanceDouble = 0;
	}
	
}

void allStatistics::casinoProfit(vector<Game>& gameForOneDay, double* profitForCasinoDay)  // for all statistics
{
	double profitForCasino = 0.0;
	
	for (int i = 0; i < gameForOneDay.size(); i++)
	{
		if (gameForOneDay[i].getEarning() <= 0)
		{
			profitForCasino += gameForOneDay[i].getBidding();
		}

		if (gameForOneDay[i].getEarning() > 0)
		{
			profitForCasino -= gameForOneDay[i].getEarning();
		}
	}

	if (gameForOneDay.size() != 0)
	{
		*profitForCasinoDay = profitForCasino;
	}
	else
	{
		*profitForCasinoDay = 0;
	}
}

// only for day statistic
void allStatistics::profitPerPlayHour(double* profitForCasinoDay, double* profitPerPlayHourDouble, struct tm* realPlayTime) 
{
	int playTimeInSeconds = (realPlayTime->tm_min * 60) + realPlayTime->tm_sec;
	double profitforday = *profitForCasinoDay;
	if (playTimeInSeconds == 0)
	{
		*profitPerPlayHourDouble = 0;
	}
	else
	{
		double profitpersecond = profitforday / playTimeInSeconds;
		*profitPerPlayHourDouble = profitpersecond * 3600;
	}
}

void allStatistics::profitPerHourForDay(double* profitForCasinoDay, double* profitPerHourForDayDouble)  // only for day statistic
{
	double profitForDay = *profitForCasinoDay;
	double profitPerSecond = profitForDay / 86400;
	*profitPerHourForDayDouble = profitPerSecond * 3600;
}
//-------------------------------------------------------------------------------------------------------------------------------------------------
/*Daily statistic ends here*/
//-------------------------------------------------------------------------------------------------------------------------------------------------


//-------------------------------------------------------------------------------------------------------------------------------------------------
/*Montly statistic starts here*/
//-------------------------------------------------------------------------------------------------------------------------------------------------

void allStatistics::writeCsvFileMonthly(FromXmlToVector month)
{
	vector <Game> gameFromMonth = month.getVector();  // hold all games for month
	
	//-----------------------------------------------------------------------------------------------------------------------------------------
	int gameByDaysArr[32] = { 0 }; // hold number of played games by days
	gameByDaysMonthly(gameFromMonth, gameByDaysArr);
	
	//-----------------------------------------------------------------------------------------------------------------------------------------
	vector<Game>  gamesByDayMonthly [32];	// hold played games by days
	for (int i = 0; i < gameFromMonth.size(); i++)			
	{
		gamesByDayMonthly[gameFromMonth[i].getStartTime().tm_mday].push_back(gameFromMonth[i]);
	}

	double balancePerDayArr[32] = {0};  // hold balance by days
	double balanceDouble = 0; // balance for curent day

	for (int i = 1; i < 32; i++)
	{
		balance(gamesByDayMonthly[i], &balanceDouble);

		balancePerDayArr[i] = balanceDouble;
	}
	
	//-----------------------------------------------------------------------------------------------------------------------------------------
	double profitArr[32] = { 0 }; // hold profit for casino by days
	double profitDay = 0; // profit for curent day
	for (int i = 1; i < 32; i++)
	{
		casinoProfit(gamesByDayMonthly[i], &profitDay);
		profitArr[i] = profitDay;
	}
	
	//-----------------------------------------------------------------------------------------------------------------------------------------
	map <string, struct tm> realPlayPerDayMonth; // hold real play time by days
	for (int i = 0; i < gameFromMonth.size(); i ++) // create string keys  - date
	{
		string dateForInsert = to_string(gameFromMonth[i].getStartTime().tm_mday) + "_" + to_string(gameFromMonth[i].getStartTime().tm_mon + 1) + "_" +
			to_string(gameFromMonth[i].getStartTime().tm_year + 1900);
		realPlayPerDayMonth[dateForInsert];
	}

	struct tm tempTmMonth; // play time for curent day

	for (int i = 0; i < gameFromMonth.size(); i++)
	{
		string date = to_string(gameFromMonth[i].getStartTime().tm_mday) + "_" + to_string(gameFromMonth[i].getStartTime().tm_mon + 1) + "_" +
			to_string(gameFromMonth[i].getStartTime().tm_year + 1900);

		realPlayGameTime(gameFromMonth, tempTmMonth, &date);
		realPlayPerDayMonth[date] = tempTmMonth;
	}
	
	//-----------------------------------------------------------------------------------------------------------------------------------------
	double monthProfitDouble = 0;  // hold profit for all month
	monthProfit(&monthProfitDouble, profitArr);
	
	//-----------------------------------------------------------------------------------------------------------------------------------------
	struct tm realPlayTimeMonth; // hold real play time for month
	realPlayTimeForMonthAndPeriod(&realPlayTimeMonth, realPlayPerDayMonth);
	
	//-----------------------------------------------------------------------------------------------------------------------------------------
	double profitByPlayHourByMonth; // hold profit for play hour 
	profitByPlayHourForMontAndPeriod(&realPlayTimeMonth, &profitByPlayHourByMonth, &monthProfitDouble);
	
	//-----------------------------------------------------------------------------------------------------------------------------------------
	double profitByHourByMonth; // hold profid by astronomic hour
	profitByHourForMont(gameFromMonth, &profitByHourByMonth, &monthProfitDouble);

	//-----------------------------------------------------------------------------------------------------------------------------------------
	ofstream writeMonthly;
	writeMonthly.open("Statistic for a month.csv", ios::out);

	if (writeMonthly.is_open())
	{
		writeMonthly << "Number ;of played ;games by ;days:" << endl;
		for (int i = 1; i < 32; i++)
		{
			writeMonthly << "Played in;" << i << " day;" << gameByDaysArr[i] << endl;
		}
		writeMonthly << endl;

		writeMonthly << "Ratio bidd ;/earning by ;days:" << endl;
		for (int i = 1; i < 32; i++)
		{
			writeMonthly << i << "; day ;" << setprecision(4) << balancePerDayArr[i] << endl;
		}
		writeMonthly << endl;

		writeMonthly << "Earning:" << endl;
		for (int i = 1; i < 32; i++)
		{
			writeMonthly << i << "; day;" << profitArr[i] << endl;
		}
		writeMonthly << endl;

		writeMonthly << "Played; time:" << endl;
		for (map<string, struct tm>::iterator it = realPlayPerDayMonth.begin(); it != realPlayPerDayMonth.end(); it++)
		{
			writeMonthly << it->first << "; ;" << it->second.tm_hour << ":" << it->second.tm_min << ":" << it->second.tm_sec << endl;
		}
		writeMonthly << endl;

		writeMonthly << "Statistic;" << "for all month:" << endl;
		writeMonthly << "Monthly;" << "winning;" << monthProfitDouble << endl;
		writeMonthly << endl;
		writeMonthly << "Play time;" << "for month;" << realPlayTimeMonth.tm_hour << ":" << realPlayTimeMonth.tm_min << ":" << realPlayTimeMonth.tm_sec << endl;
		writeMonthly << endl;
		writeMonthly << "Profit by;" << "play hours;" << profitByPlayHourByMonth << endl;
		writeMonthly << endl;
		writeMonthly << "Profit by;" << "hours;" << setprecision(4) << profitByHourByMonth << endl;

		writeMonthly.close();
		cout << "File is successfully created!" << endl;
	}
	else
	{
		cout << "File is not created!" << endl;
	}
}

void allStatistics::gameByDaysMonthly(vector <Game>& gameFromMonth, int* gameByDaysArr) // only for monthly statistics
{
	for (int i = 0; i < gameFromMonth.size(); i++)
	{
		gameByDaysArr[gameFromMonth[i].getStartTime().tm_mday] ++;
	}
}

void allStatistics::realPlayGameTime(vector <Game>& gameFromMonth, struct tm& realPlayTime, string* date) // for month and period
{
	realPlayTime.tm_hour = 0;
	realPlayTime.tm_min = 0;
	realPlayTime.tm_sec = 0;

	for (int i = 0; i < gameFromMonth.size(); i++)
	{
		string tempDate = to_string(gameFromMonth[i].getStartTime().tm_mday) + "_" + to_string(gameFromMonth[i].getStartTime().tm_mon + 1) + "_" +
			to_string(gameFromMonth[i].getStartTime().tm_year + 1900);

		if (tempDate == *date)
		{
			
			realPlayTime.tm_min += gameFromMonth[i].getPlayingTime().tm_min;
			realPlayTime.tm_sec += gameFromMonth[i].getPlayingTime().tm_sec;

			if (realPlayTime.tm_sec > 59)
			{
				realPlayTime.tm_sec = realPlayTime.tm_sec % 60;
				realPlayTime.tm_min++;
			}
			if (realPlayTime.tm_min > 59)
			{
				realPlayTime.tm_min = realPlayTime.tm_min % 60;
				realPlayTime.tm_hour++;
			}
		}
	}
}

void allStatistics::monthProfit(double* monthProfitDouble, double* profitArr) // only for month
{
	for (int i = 1; i < 32; i++)
	{
		*monthProfitDouble += profitArr[i];
	}
}

void allStatistics::realPlayTimeForMonthAndPeriod(struct tm* realPlayTimeMonth, map<string, struct tm>& realPlayPerDayMonth) // use for month and period
{
	realPlayTimeMonth->tm_hour = 0;
	realPlayTimeMonth->tm_min = 0;
	realPlayTimeMonth->tm_sec = 0;

	for (map<string, struct tm>::iterator it = realPlayPerDayMonth.begin(); it != realPlayPerDayMonth.end(); it++)
	{
		realPlayTimeMonth->tm_min += it->second.tm_min;
		realPlayTimeMonth->tm_sec += it->second.tm_sec;

		if (realPlayTimeMonth->tm_sec > 59)
		{
			realPlayTimeMonth->tm_sec = realPlayTimeMonth->tm_sec % 60;
			realPlayTimeMonth->tm_min++;
		}
		if (realPlayTimeMonth->tm_min > 59)
		{
			realPlayTimeMonth->tm_min = realPlayTimeMonth->tm_min % 60;
			realPlayTimeMonth->tm_hour++;
		}

	}
}

void allStatistics::profitByPlayHourForMontAndPeriod(struct tm* realPlayTime, double* profitByPlayHour, double* ProfitDouble) // for month and period
{
	if (*ProfitDouble == 0)
	{
		*profitByPlayHour = 0;
	}
	else
	{
		int playedSecondsPerMonth = (realPlayTime->tm_hour * 3600) + (realPlayTime->tm_min * 60) + realPlayTime->tm_sec;
		*profitByPlayHour = *ProfitDouble / playedSecondsPerMonth;
		*profitByPlayHour *= 3600;
	}
}

void allStatistics::profitByHourForMont(vector <Game>& gameFromMonth, double* profitByHourByMonth, double* monthProfitDouble) // only for month
{
	int monthSeconds;

	if (gameFromMonth.size() == 0)
	{
		*profitByHourByMonth = 0;
	}
	else
	{
		switch (1 + gameFromMonth[0].getStartTime().tm_mon)
		{
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			monthSeconds = 2678400;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			monthSeconds = 2592000;
			break;
		default:
			monthSeconds = 2419200;
			break;
		}

		*profitByHourByMonth = *monthProfitDouble / monthSeconds;
		*profitByHourByMonth *= 3600;
	}
}
//-------------------------------------------------------------------------------------------------------------------------------------------------
/*Montly statistic ends here*/
//-------------------------------------------------------------------------------------------------------------------------------------------------


//-------------------------------------------------------------------------------------------------------------------------------------------------
/*Period statistic starts here*/
//-------------------------------------------------------------------------------------------------------------------------------------------------

void allStatistics::writeCsvFileForPeriod(FromXmlToVector period)
{
	vector <Game> gamesFromPeriod = period.getVector(); // hold all games for period

	map<string, int> gamesPerDaysPeriod; // number of games for period by days
	gameByDaysPeriod(gamesFromPeriod, gamesPerDaysPeriod);

	// ------------------------------------------------------------------------------------------------------------------------------------------
	map<string,vector <Game> > daysFromPeriod; // hold all games distributed by days
	map<string, double> balansByDayForPeriod;  // hold balance by days

	balanceForDayFromPeriod(daysFromPeriod, balansByDayForPeriod, gamesFromPeriod);

	// ------------------------------------------------------------------------------------------------------------------------------------------
	map<string, double> profitPerDayFromPeriod;	// hold profit by days 

	for (int i = 0; i < gamesFromPeriod.size(); i++)
	{
		string tempKey = to_string(gamesFromPeriod[i].getStartTime().tm_mday) + "_" + to_string(gamesFromPeriod[i].getStartTime().tm_mon + 1) + "_" +
			to_string(gamesFromPeriod[i].getStartTime().tm_year);
		profitPerDayFromPeriod[tempKey];
	}
	double profitForCasinoDayPeriod = 0; //  curent day
	for (map<string, vector <Game> >::iterator it = daysFromPeriod.begin(); it != daysFromPeriod.end(); it++)
	{
		casinoProfit(it->second, &profitForCasinoDayPeriod);
		profitPerDayFromPeriod[it->first] = profitForCasinoDayPeriod;
	}

	// ------------------------------------------------------------------------------------------------------------------------------------------
	map<string, struct tm> realPlayTimePeriod;	//hold real play time by days

	struct tm tempTm; // curent day

	// create string kays - date
	for (int i = 0; i < gamesFromPeriod.size(); i++)
	{
		string tempKey = to_string(gamesFromPeriod[i].getStartTime().tm_mday) + "_" + to_string(gamesFromPeriod[i].getStartTime().tm_mon + 1) + "_" +
			to_string(gamesFromPeriod[i].getStartTime().tm_year + 1900);
		realPlayTimePeriod[tempKey];
	}
	

	for (int i = 0; i < gamesFromPeriod.size(); i++)
	{
		string tempDate = to_string(gamesFromPeriod[i].getStartTime().tm_mday) + "_" + to_string(gamesFromPeriod[i].getStartTime().tm_mon + 1) + "_" +
			to_string(gamesFromPeriod[i].getStartTime().tm_year + 1900);

		realPlayGameTime(gamesFromPeriod, tempTm, &tempDate);
		realPlayTimePeriod[tempDate] = tempTm;

	}

	// ------------------------------------------------------------------------------------------------------------------------------------------
	double periodProfit = 0.0; // profit for period
	profitForPeriod(profitPerDayFromPeriod, &periodProfit);

	// ------------------------------------------------------------------------------------------------------------------------------------------
	struct tm realPlayTimePeriodStruct;	//hold real play time for period
	realPlayTimeForMonthAndPeriod(&realPlayTimePeriodStruct, realPlayTimePeriod);

	// ------------------------------------------------------------------------------------------------------------------------------------------
	double profitByPlayHourByPeriod = 0.0;	//hold profit for play hour
	profitByPlayHourForMontAndPeriod(&realPlayTimePeriodStruct, &profitByPlayHourByPeriod, &periodProfit);

	// ------------------------------------------------------------------------------------------------------------------------------------------
	double profitPerHoursPeriodDouble = 0.0; //hold profit for astronomic hour
	profitPerHoursPeriod(&periodProfit, &profitPerHoursPeriodDouble);

	// ------------------------------------------------------------------------------------------------------------------------------------------
	ofstream writePeriod;
	writePeriod.open("Statistic for period.csv", ios::out);
	if (writePeriod.is_open())
	{
		writePeriod << "Games by; day" << endl;
		for (map<string, int>::iterator it = gamesPerDaysPeriod.begin(); it != gamesPerDaysPeriod.end(); it++)
		{
			writePeriod << it->first << ";" << "games:;" << it->second << endl;
		}
		writePeriod << endl;

		writePeriod << "Ratio bidd;/earning; day" << endl;
		for (map<string, double>::iterator it = balansByDayForPeriod.begin(); it != balansByDayForPeriod.end(); it++)
		{
			writePeriod << it->first << "; ;" << setprecision(4) << it->second << endl;
		}
		writePeriod << endl;

		writePeriod << "Profit by; days" << endl;
		for (map<string, double>::iterator it = profitPerDayFromPeriod.begin(); it != profitPerDayFromPeriod.end(); it++)
		{
			writePeriod << it->first << "; ;" << it->second << endl;
		}
		writePeriod << endl;

		writePeriod << "Play time; by days" << endl;
		for (map<string, struct tm>::iterator it = realPlayTimePeriod.begin(); it != realPlayTimePeriod.end(); it++)
		{
			writePeriod << it->first << "; ;" << it->second.tm_hour << ":" << it->second.tm_min << ":" << it->second.tm_sec << endl;
		}
		writePeriod << endl;

		writePeriod << "Statistics ;for all period" << endl;
		writePeriod << "profit: ; ;" << periodProfit << endl;
		writePeriod << endl;

		writePeriod << "real play;" << "time:;" << realPlayTimePeriodStruct.tm_hour << ":" << realPlayTimePeriodStruct.tm_min << ":" <<
			realPlayTimePeriodStruct.tm_sec << endl;
		writePeriod << endl;

		writePeriod << "profit per;" << "play hour:;" << profitByPlayHourByPeriod << endl;
		writePeriod << endl;

		writePeriod << "profit per;" << "hour:;" << setprecision(4) << profitPerHoursPeriodDouble << endl;
		
		writePeriod.close();
		cout << "File is successfully created!" << endl;
	}
	else
	{
		cout << "File is not created!" << endl;
	}
}
// ------------------------------------------------------------------------------------------------------------------------------------------------

void allStatistics::gameByDaysPeriod(vector <Game>& gamesFromPeriod, map<string, int>& gamesPerDaysPeriod) // only for period
{
	for (int i = 0; i < gamesFromPeriod.size(); i++)
	{
		string tempKey = to_string(gamesFromPeriod[i].getStartTime().tm_mday) + "_" + to_string(gamesFromPeriod[i].getStartTime().tm_mon + 1) + "_" +
			to_string(gamesFromPeriod[i].getStartTime().tm_year);
		gamesPerDaysPeriod[tempKey] ++;
	}
}

// only for period
void allStatistics::balanceForDayFromPeriod(map<string, vector <Game> >& daysFromPeriod, map<string, double>& balansByDayForPeriod, vector <Game>& gamesFromPeriod)
{
	for (int i = 0; i < gamesFromPeriod.size(); i++)
	{
		string tempKey = to_string(gamesFromPeriod[i].getStartTime().tm_mday) + "_" + to_string(gamesFromPeriod[i].getStartTime().tm_mon + 1) + "_" +
			to_string(gamesFromPeriod[i].getStartTime().tm_year);
		daysFromPeriod[tempKey];
	}

	for (map<string, vector <Game> >::iterator it = daysFromPeriod.begin(); it != daysFromPeriod.end(); it++)
	{
		for (size_t i = 0; i < gamesFromPeriod.size(); i++)
		{
			string tempKey = to_string(gamesFromPeriod[i].getStartTime().tm_mday) + "_" + to_string(gamesFromPeriod[i].getStartTime().tm_mon + 1) +
				"_" + to_string(gamesFromPeriod[i].getStartTime().tm_year);

			if (tempKey == it->first)
			{
				it->second.push_back(gamesFromPeriod[i]);
			}
		}
	}
	double balanceForDayPeriod = 0;

	for (map<string, vector <Game> >::iterator it = daysFromPeriod.begin(); it != daysFromPeriod.end(); it++)
	{
		balance(it->second, &balanceForDayPeriod);
		balansByDayForPeriod[it->first] = balanceForDayPeriod;
	}
}

void allStatistics::profitForPeriod(map<string, double>& profitPerDayFromPeriod, double* profitForMonthDouble) // only for period
{
	for (map<string, double>::iterator it = profitPerDayFromPeriod.begin(); it != profitPerDayFromPeriod.end(); it++)
	{
		*profitForMonthDouble += it->second;
	}
}

void allStatistics::setPeriodDays(int periodDays)
{
	this->periodDays = periodDays;
}

void allStatistics::profitPerHoursPeriod(double* periodProfit, double* profitPerHoursPeriodDouble) // only for period
{
	if (*periodProfit == 0)
	{
		*profitPerHoursPeriodDouble = 0;
	}
	else
	{
		int hoursPerPeriod = this->periodDays * 24;
		*profitPerHoursPeriodDouble = *periodProfit / hoursPerPeriod;
	}
}

//-------------------------------------------------------------------------------------------------------------------------------------------------
/*Period statistic ends here*/
//-------------------------------------------------------------------------------------------------------------------------------------------------